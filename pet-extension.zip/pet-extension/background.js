// 背景程式：從 GitHub Pages 讀取名冊與圖片，交給各分頁使用
importScripts('js-yaml.min.js');

const BASE = 'https://mcxpurple.github.io/pet/';
const DEFAULTS = { size: 120, speed: '中', sleep_after: 60, effect_click: '愛心', effect_sleep: 'zzz', images: ['idle'], extras: [] };
const CORE = ['idle', 'sleep', 'click', 'drag'];
const MAX_VARIANTS = 5;
const ROSTER_TTL = 10 * 60 * 1000;

let rosterCache = null, rosterAt = 0;
const imageCache = new Map();

async function exists(url) {
  try { const r = await fetch(url, { method: 'HEAD', cache: 'no-cache' }); return r.ok; }
  catch { return false; }
}

async function probeState(id, state) {
  const names = [state, ...Array.from({ length: MAX_VARIANTS }, (_, k) => `${state}_${k + 1}`)];
  const urls = names.map(n => `${BASE}pets/${id}/${n}.png`);
  const ok = await Promise.all(urls.map(exists));
  return urls.filter((_, i) => ok[i]);
}

async function getRoster(force) {
  if (!force && rosterCache && Date.now() - rosterAt < ROSTER_TTL) return rosterCache;
  const text = await (await fetch(BASE + 'roster.yaml', { cache: 'no-cache' })).text();
  const raw = jsyaml.load(text) || [];
  const list = await Promise.all(raw.map(async r => {
    const c = { ...DEFAULTS, ...r };
    c.extras = c.extras || [];
    const states = [...new Set([...CORE, ...(c.images || []), ...c.extras])];
    c.sets = {};
    await Promise.all(states.map(async s => { c.sets[s] = await probeState(c.id, s); }));
    return c.sets.idle.length ? c : null;
  }));
  rosterCache = list.filter(Boolean);
  rosterAt = Date.now();
  return rosterCache;
}

function toBase64(buf) {
  const bytes = new Uint8Array(buf);
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(bin);
}

async function getImage(url) {
  if (!url.startsWith(BASE)) throw new Error('blocked url');
  if (imageCache.has(url)) return imageCache.get(url);
  const r = await fetch(url);
  if (!r.ok) throw new Error('image ' + r.status);
  const b64 = toBase64(await r.arrayBuffer());
  imageCache.set(url, b64);
  return b64;
}

chrome.runtime.onMessage.addListener((msg, sender, send) => {
  const job =
    msg.type === 'roster' ? getRoster(msg.force) :
    msg.type === 'image' ? getImage(msg.url) :
    Promise.reject(new Error('unknown'));
  job.then(data => send({ data })).catch(e => send({ error: String(e) }));
  return true;
});
