// 背景程式：從 GitHub Pages 讀取名冊與圖片，交給各分頁使用
importScripts('js-yaml.min.js', 'pet-engine.js');

const BASE = 'https://mcxpurple.github.io/pet/';
const ROSTER_TTL = 10 * 60 * 1000;
let rosterCache = null, rosterAt = 0;
const imageCache = new Map();

async function getRoster(force) {
  if (!force && rosterCache && Date.now() - rosterAt < ROSTER_TTL) return rosterCache;
  rosterCache = await QPet.loadRoster(BASE);
  rosterAt = Date.now();
  return rosterCache;
}

function toBase64(buf) {
  const bytes = new Uint8Array(buf);
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(bin);
}

async function getImage(url) {
  if (!url.startsWith(BASE)) throw new Error('blocked url');
  if (imageCache.has(url)) return imageCache.get(url);
  const r = await fetch(url);
  if (!r.ok) throw new Error('image ' + r.status);
  const b64 = toBase64(await r.arrayBuffer());
  imageCache.set(url, b64);
  return b64;
}

chrome.runtime.onMessage.addListener((msg, sender, send) => {
  const job =
    msg.type === 'roster' ? getRoster(msg.force) :
    msg.type === 'image' ? getImage(msg.url) :
    msg.type === 'version' ? fetch(BASE + 'version.json', { cache: 'no-cache' }).then(r => r.json()) :
    Promise.reject(new Error('unknown'));
  job.then(data => send({ data })).catch(e => send({ error: String(e) }));
  return true;
});
