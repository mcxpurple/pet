/*
 * Violet Hour 紫夜星光｜Q版桌寵
 * © 2026 mcx_purple. All rights reserved.
 * 保留所有權利，未經同意請勿複製、修改或用於其他專案。
 * https://www.threads.com/@mcx_purple
 */
const $ = id => document.getElementById(id);
let pick = [], enabled = true, roster = null;

const send = msg => new Promise((res, rej) =>
  chrome.runtime.sendMessage(msg, r => (r && !r.error ? res(r.data) : rej(new Error(r ? r.error : 'no response')))));

/* ===== 主畫面 ===== */
function renderPower() {
  $('power').setAttribute('aria-checked', String(enabled));
  $('status').textContent = enabled ? '角色正在網頁上散步' : '角色暫時休息，不會出現';
}
$('power').onclick = () => { enabled = !enabled; chrome.storage.local.set({ enabled }); renderPower(); };

function polaroid(c) {
  const b = document.createElement('div'); b.className = c ? 'pol' : 'pol empty';
  const ph = document.createElement('div'); ph.className = 'ph';
  if (c) { const img = document.createElement('img'); img.src = c.thumb; img.alt = ''; ph.appendChild(img); }
  else ph.textContent = '+';
  const nm = document.createElement('div'); nm.className = 'nm'; nm.textContent = c ? c.name : '空位';
  b.append(ph, nm);
  return b;
}
function renderNow() {
  const box = $('now'); box.innerHTML = '';
  if (!roster) { box.innerHTML = '<div class="msg" style="grid-column:1/-1">載入中…</div>'; return; }
  const list = pick.map(id => roster.find(c => c.id === id)).filter(Boolean);
  const slots = Math.max(2, Math.min(4, list.length + 1));
  for (let i = 0; i < slots; i++) box.appendChild(polaroid(list[i]));
}

/* ===== 選角畫面 ===== */
function show(view) { $('home').hidden = view !== 'home'; $('pick').hidden = view !== 'pick'; }
function renderPicker() {
  if (!roster) return;
  if (!roster.length) { $('grid').innerHTML = '<div class="msg">目前沒有可用角色</div>'; return; }
  QPet.picker({ select: $('group'), grid: $('grid'), picked: $('picked'), roster, pick, max: 4,
    onChange: p => { pick = p; chrome.storage.local.set({ pick: p }); } });
}
$('toPick').onclick = () => { show('pick'); renderPicker(); };
$('back').onclick = () => { show('home'); renderNow(); };

async function loadRoster(force) {
  roster = null; renderNow();
  try { roster = await send({ type: 'roster', force }); }
  catch { roster = []; $('grid').innerHTML = '<div class="msg">名冊讀取失敗，請確認網路後重試</div>'; }
  renderNow(); if (!$('pick').hidden) renderPicker();
}
$('reload').onclick = () => loadRoster(true);

/* ===== 版本提醒 ===== */
const MINE = chrome.runtime.getManifest().version;
$('ver').textContent = 'v' + MINE;
const newer = (a, b) => { const x = a.split('.').map(Number), y = b.split('.').map(Number);
  for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); return false; };
send({ type: 'version' }).then(v => {
  if (!v || !newer(String(v.version), MINE)) return;
  const a = $('upd'); a.textContent = `✦ 有新版本 v${v.version}，點此重新安裝 ›`; a.hidden = false;
  a.onclick = e => { e.preventDefault(); chrome.tabs.create({ url: 'https://mcxpurple.github.io/pet/install.html' }); };
}).catch(() => {});

chrome.storage.local.get({ pick: [], enabled: true, size: '中' }, s => {
  pick = s.pick; enabled = s.enabled;
  renderPower(); loadRoster(false);
  QPet.sizeSeg($('size'), s.size, size => chrome.storage.local.set({ size }));
});
