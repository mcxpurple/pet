const $ = id => document.getElementById(id);
const grid = $('grid');
let pick = [], enabled = true, roster = null;

const send = msg => new Promise((res, rej) =>
  chrome.runtime.sendMessage(msg, r => (r && !r.error ? res(r.data) : rej(new Error(r ? r.error : 'no response')))));

/* ===== 主畫面 ===== */
function renderPower() {
  $('power').setAttribute('aria-checked', String(enabled));
  $('powerText').textContent = enabled ? '開啟中' : '已關閉';
  $('powerSub').textContent = enabled ? '角色正在網頁上散步' : '角色暫時休息，不會出現';
  $('home').classList.toggle('dim', !enabled);
}
function renderNow() {
  const box = $('nowList');
  box.innerHTML = '';
  const list = roster ? pick.map(id => roster.find(c => c.id === id)).filter(Boolean) : [];
  if (!list.length) { box.innerHTML = `<span class="none">${roster ? '還沒有選角色' : '載入中…'}</span>`; return; }
  list.forEach(c => {
    const el = document.createElement('span'); el.className = 'who';
    const img = document.createElement('img'); img.src = c.sets.idle[0]; img.alt = '';
    el.append(img, document.createTextNode(c.name));
    box.appendChild(el);
  });
}
$('power').onclick = () => {
  enabled = !enabled;
  chrome.storage.local.set({ enabled });
  renderPower();
};

/* ===== 選角畫面 ===== */
function show(view) { $('home').hidden = view !== 'home'; $('pick').hidden = view !== 'pick'; }
$('toPick').onclick = () => { show('pick'); renderGrid(); };
$('back').onclick = () => { show('home'); renderNow(); };

function refresh() {
  [...grid.querySelectorAll('.choice')].forEach(b => {
    const i = pick.indexOf(b.dataset.id);
    b.classList.toggle('on', i >= 0);
    b.querySelector('.badge').textContent = i >= 0 ? i + 1 : '';
  });
}
function renderGrid() {
  if (!roster) { grid.innerHTML = '<div class="msg">載入角色中…</div>'; return; }
  if (!roster.length) { grid.innerHTML = '<div class="msg">目前沒有可用角色</div>'; return; }
  grid.innerHTML = '';
  roster.forEach(c => {
    const b = document.createElement('button');
    b.className = 'choice'; b.dataset.id = c.id;
    const badge = document.createElement('span'); badge.className = 'badge';
    const img = document.createElement('img'); img.src = c.sets.idle[0]; img.alt = '';
    const nm = document.createElement('div'); nm.className = 'nm'; nm.textContent = c.name;
    const gp = document.createElement('div'); gp.className = 'gp'; gp.textContent = c.group || '';
    b.append(badge, img, nm, gp);
    b.onclick = () => {
      const i = pick.indexOf(c.id);
      if (i >= 0) pick.splice(i, 1);
      else { if (pick.length >= 2) pick.shift(); pick.push(c.id); }
      chrome.storage.local.set({ pick: pick.slice() });
      refresh();
    };
    grid.appendChild(b);
  });
  refresh();
}

async function loadRoster(force) {
  roster = null;
  renderNow(); if (!$('pick').hidden) renderGrid();
  try { roster = await send({ type: 'roster', force }); }
  catch { roster = []; grid.innerHTML = '<div class="msg">名冊讀取失敗，請確認網路後重試</div>'; renderNow(); return; }
  renderNow(); if (!$('pick').hidden) renderGrid();
}
$('reload').onclick = () => loadRoster(true);

chrome.storage.local.get({ pick: [], enabled: true }, s => {
  pick = s.pick; enabled = s.enabled;
  renderPower();
  loadRoster(false);
});
