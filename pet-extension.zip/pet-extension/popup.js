const grid = document.getElementById('grid');
const enabled = document.getElementById('enabled');
let pick = [];

const send = msg => new Promise((res, rej) =>
  chrome.runtime.sendMessage(msg, r => (r && !r.error ? res(r.data) : rej(new Error(r ? r.error : 'no response')))));

function refresh() {
  [...grid.querySelectorAll('.choice')].forEach(b => {
    const i = pick.indexOf(b.dataset.id);
    b.classList.toggle('on', i >= 0);
    b.querySelector('.badge').textContent = i >= 0 ? i + 1 : '';
  });
}

async function load(force) {
  grid.innerHTML = '<div class="msg">載入角色中…</div>';
  let roster;
  try { roster = await send({ type: 'roster', force }); }
  catch { grid.innerHTML = '<div class="msg">名冊讀取失敗，請確認網路後重試</div>'; return; }
  if (!roster.length) { grid.innerHTML = '<div class="msg">目前沒有可用角色</div>'; return; }
  grid.innerHTML = '';
  roster.forEach(c => {
    const b = document.createElement('button');
    b.className = 'choice'; b.dataset.id = c.id;
    const img = document.createElement('img'); img.src = c.sets.idle[0]; img.alt = '';
    const nm = document.createElement('div'); nm.className = 'nm'; nm.textContent = c.name;
    const gp = document.createElement('div'); gp.className = 'gp'; gp.textContent = c.group || '';
    const badge = document.createElement('span'); badge.className = 'badge';
    b.append(badge, img, nm, gp);
    b.onclick = () => {
      const i = pick.indexOf(c.id);
      if (i >= 0) pick.splice(i, 1);
      else { if (pick.length >= 2) pick.shift(); pick.push(c.id); }
      chrome.storage.local.set({ pick: pick.slice() });
      refresh();
    };
    grid.appendChild(b);
  });
  refresh();
}

chrome.storage.local.get({ pick: [], enabled: true }, s => {
  pick = s.pick; enabled.checked = s.enabled;
  load(false);
});
enabled.onchange = () => chrome.storage.local.set({ enabled: enabled.checked });
document.getElementById('reload').onclick = () => load(true);
