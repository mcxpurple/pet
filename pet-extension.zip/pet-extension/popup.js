/*
 * Violet Hour 紫夜星光｜陪伴桌寵
 * © 2026 mcx_purple. All rights reserved.
 * 保留所有權利，未經同意請勿複製、修改或用於其他專案。
 * https://www.threads.com/@mcx_purple
 */
const $ = id => document.getElementById(id);
let pick = [], enabled = true, roster = null, sizeEach = {}, blockSites = [], site = '';

const send = msg => new Promise((res, rej) =>
  chrome.runtime.sendMessage(msg, r => (r && !r.error ? res(r.data) : rej(new Error(r ? r.error : 'no response')))));

/* ===== 主畫面 ===== */
function renderPower() {
  $('power').setAttribute('aria-checked', String(enabled));
  $('status').textContent = enabled ? '角色正在網頁上散步' : '角色暫時休息，不會出現';
}
$('power').onclick = () => { enabled = !enabled; chrome.storage.local.set({ enabled }); renderPower(); };
// 快捷鍵切換時，開著的主畫面同步更新
chrome.storage.onChanged.addListener((ch, area) => {
  if (area === 'local' && ch.enabled) { enabled = ch.enabled.newValue !== false; renderPower(); }
});

function polaroid(c) {
  const b = document.createElement('div'); b.className = c ? 'pol' : 'pol empty';
  const ph = document.createElement('div'); ph.className = 'ph';
  if (c) { const img = document.createElement('img'); img.src = c.thumb; img.alt = ''; ph.appendChild(img); }
  else ph.textContent = '+';
  const nm = document.createElement('div'); nm.className = 'nm'; nm.textContent = c ? c.name : '空位';
  b.append(ph, nm);
  return b;
}
/* 個別大小：小 0.85｜標準 1｜大 1.15，存在 sizeEach，所有分頁同步 */
const SCALES = [['小', .85], ['標準', 1], ['大', 1.15]];
let openMenu = '';
const scaleText = id => { const v = Number(sizeEach[id]) || 1; return v < 1 ? '小' : v > 1 ? '大' : '⋯'; };
function sizeButton(c, slot) {
  const btn = document.createElement('button');
  btn.type = 'button'; btn.className = 'more'; btn.textContent = scaleText(c.id);
  btn.title = c.name + ' 的個別大小';
  btn.setAttribute('aria-expanded', String(openMenu === c.id));
  btn.onclick = e => { e.stopPropagation(); openMenu = openMenu === c.id ? '' : c.id; renderNow(); };
  slot.appendChild(btn);
  if (openMenu !== c.id) return;
  const menu = document.createElement('div'); menu.className = 'smenu';
  menu.innerHTML = '<b></b><div class="seg"></div>';
  menu.querySelector('b').textContent = c.name + '・個別大小';
  const seg = menu.querySelector('.seg');
  const cur = Number(sizeEach[c.id]) || 1;
  SCALES.forEach(([t, v]) => {
    const b = document.createElement('button'); b.type = 'button'; b.textContent = t;
    b.setAttribute('aria-pressed', String(cur === v));
    b.onclick = e => {
      e.stopPropagation();
      const next = { ...sizeEach }; if (v === 1) delete next[c.id]; else next[c.id] = v;
      sizeEach = next; openMenu = ''; chrome.storage.local.set({ sizeEach }); renderNow();
    };
    seg.appendChild(b);
  });
  menu.onclick = e => e.stopPropagation();
  slot.appendChild(menu);
}
document.addEventListener('click', () => { if (openMenu) { openMenu = ''; renderNow(); } });

function renderNow() {
  const box = $('now'); box.innerHTML = '';
  if (!roster) { box.innerHTML = '<div class="msg" style="grid-column:1/-1">載入中…</div>'; return; }
  const list = pick.map(id => roster.find(c => c.id === id)).filter(Boolean);
  const slots = Math.max(2, Math.min(4, list.length + 1));
  for (let i = 0; i < slots; i++) {
    const slot = document.createElement('div'); slot.className = 'slot';
    slot.appendChild(polaroid(list[i]));
    if (list[i]) sizeButton(list[i], slot);
    box.appendChild(slot);
  }
}

/* ===== 指定網站不出現 ===== */
function renderSite() {
  const hidden = blockSites.includes(site);
  $('site').hidden = !site;
  $('dom').textContent = site;
  $('siteBtn').textContent = hidden ? '恢復在這個網站出現' : '在這個網站隱藏';
  $('siteBtn').classList.toggle('on', hidden);
  $('blockBox').hidden = !blockSites.length;
  $('blockSum').textContent = '已隱藏的網站（' + blockSites.length + '）';
  const list = $('blockList'); list.innerHTML = '';
  blockSites.forEach(d => {
    const b = document.createElement('button'); b.type = 'button'; b.textContent = d + ' ×'; b.title = '恢復在 ' + d + ' 出現';
    b.onclick = () => { blockSites = blockSites.filter(x => x !== d); chrome.storage.local.set({ blockSites }); renderSite(); };
    list.appendChild(b);
  });
}
$('siteBtn').onclick = () => {
  blockSites = blockSites.includes(site) ? blockSites.filter(x => x !== site) : [...blockSites, site];
  chrome.storage.local.set({ blockSites }); renderSite();
};
chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
  try {
    const u = new URL((tabs[0] && tabs[0].url) || '');
    if (/^https?:$/.test(u.protocol)) site = u.hostname.replace(/^www\./, '');
  } catch {}
  renderSite();
});

/* ===== 選角畫面 ===== */
function show(view) { $('home').hidden = view !== 'home'; $('pick').hidden = view !== 'pick'; }
function renderPicker() {
  if (!roster) return;
  if (!roster.length) { $('grid').innerHTML = '<div class="msg">目前沒有可用角色</div>'; return; }
  QPet.picker({ select: $('group'), grid: $('grid'), picked: $('picked'), roster, pick, max: 4,
    onChange: p => { pick = p; chrome.storage.local.set({ pick: p }); } });
}
$('toPick').onclick = () => { show('pick'); renderPicker(); };
$('back').onclick = () => { show('home'); renderNow(); };

async function loadRoster(force) {
  roster = null; renderNow();
  try { roster = await send({ type: 'roster', force }); }
  catch { roster = []; $('grid').innerHTML = '<div class="msg">名冊讀取失敗，請確認網路後重試</div>'; }
  renderNow(); if (!$('pick').hidden) renderPicker();
}
$('reload').onclick = () => loadRoster(true);

/* ===== 版本提醒 ===== */
const MINE = chrome.runtime.getManifest().version;
$('ver').textContent = 'v' + MINE;
const newer = (a, b) => { const x = a.split('.').map(Number), y = b.split('.').map(Number);
  for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); return false; };
send({ type: 'version' }).then(v => {
  if (!v || !newer(String(v.version), MINE)) return;
  const a = $('upd'); a.textContent = `✦ 有新版本 v${v.version}，點此重新安裝 ›`; a.hidden = false;
  a.onclick = e => { e.preventDefault(); chrome.tabs.create({ url: 'https://mcxpurple.github.io/pet/install.html' }); };
}).catch(() => {});

chrome.storage.local.get({ pick: [], enabled: true, size: '中', sizeEach: {}, blockSites: [] }, s => {
  pick = s.pick; enabled = s.enabled; sizeEach = s.sizeEach || {}; blockSites = s.blockSites || [];
  renderSite();
  renderPower(); loadRoster(false);
  QPet.sizeSeg($('size'), s.size, size => chrome.storage.local.set({ size }));
});
