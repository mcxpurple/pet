/*
 * Violet Hour 紫夜星光｜Q版桌寵
 * © 2026 mcx_purple. All rights reserved.
 * 保留所有權利，未經同意請勿複製、修改或用於其他專案。
 * https://www.threads.com/@mcx_purple
 */
// 擴充功能版：把共用引擎與季節微景疊在每個網頁最上層
(() => {
  if (window.top !== window || window.__qpet) return;
  window.__qpet = true;

  const send = msg => new Promise((res, rej) => {
    try {
      chrome.runtime.sendMessage(msg, r => {
        if (chrome.runtime.lastError) return rej(chrome.runtime.lastError);
        r && !r.error ? res(r.data) : rej(new Error(r ? r.error : 'no response'));
      });
    } catch (e) { rej(e); }
  });

  // Shadow DOM 疊層，與網頁樣式隔離
  const host = document.createElement('div');
  host.style.cssText = 'all:initial;position:fixed;inset:0;pointer-events:none;z-index:2147483647;';
  const root = host.attachShadow({ mode: 'open' });
  const stage = document.createElement('div');
  root.appendChild(stage);
  // 吃飯提醒一天一次，所有網頁共用同一筆紀錄
  const once = key => new Promise(res => chrome.storage.local.get({ meal: '' }, s => {
    if (s.meal === key) return res(false);
    chrome.storage.local.set({ meal: key }, () => res(true));
  }));
  // 個別大小存在 chrome.storage（sizeEach），不寫入各網站自己的 localStorage
  const world = new QPet.World(stage, { max: 4, once, petScales: {},
    saveScales: map => chrome.storage.local.set({ sizeEach: map }) });

  // 圖片由背景程式取得後解成點陣圖，不受網頁安全政策影響
  const cache = new Map();
  function loadBitmap(url) {
    if (!cache.has(url)) cache.set(url, send({ type: 'image', url }).then(b64 => {
      const bin = atob(b64), arr = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
      return createImageBitmap(new Blob([arr], { type: 'image/png' }));
    }));
    return cache.get(url);
  }
  async function loadSets(c) {
    const out = {};
    await Promise.all(Object.entries(c.sets).map(async ([s, urls]) => {
      out[s] = (await Promise.all(urls.map(u => loadBitmap(u).catch(() => null)))).filter(Boolean);
    }));
    return out;
  }

  // 指定網站不出現：以主機名稱比對，www. 視為同一網站
  const site = location.hostname.replace(/^www\./, '');
  const blocked = s => (s.blockSites || []).includes(site);

  let runId = 0;
  async function apply(s) {
    const id = ++runId;
    world.clear();
    if (!s.enabled || !s.pick.length || blocked(s)) { host.remove(); return; }
    let roster;
    try { roster = await send({ type: 'roster' }); } catch { return; }
    const chosen = s.pick.map(i => roster.find(c => c.id === i)).filter(Boolean).slice(0, 4);
    const list = await Promise.all(chosen.map(async c => ({ cfg: c, bitmaps: await loadSets(c) })));
    if (id !== runId) return;
    if (!host.isConnected) document.documentElement.appendChild(host);
    world.set(list);
  }

  const DEF = { pick: [], enabled: true, size: '中', sizeEach: {}, blockSites: [] };
  chrome.storage.local.get(DEF, s => { world.setSize(s.size); world.setPetScales(s.sizeEach); apply(s); });
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local') return;
    if (ch.size) world.setSize(ch.size.newValue);
    if (ch.sizeEach) world.setPetScales(ch.sizeEach.newValue || {});
    if (ch.pick || ch.enabled || ch.blockSites) chrome.storage.local.get(DEF, apply);
    if (ch.animal) animal = ch.animal.newValue || animal;
  });

  // 被捲動嚇到：0.3 秒內捲動超過約 1.2 個視窗高度才算快速捲動；慢慢閱讀不會觸發
  const lastTop = new WeakMap();
  let burst = 0, burstAt = 0;
  document.addEventListener('scroll', e => {
    if (!host.isConnected) return;
    const el = e.target === document ? (document.scrollingElement || document.documentElement) : e.target;
    if (!el || typeof el.scrollTop !== 'number') return;
    const top = el.scrollTop, prev = lastTop.has(el) ? lastTop.get(el) : top;
    lastTop.set(el, top);
    const now = performance.now();
    if (now - burstAt > 300) burst = 0;
    burstAt = now; burst += Math.abs(top - prev);
    if (burst > Math.max(900, innerHeight * 1.2)) { burst = 0; world.startle(); }
  }, { capture: true, passive: true });

  // 季節動物彩蛋：每 60 分鐘抽一次、20% 機率；開始後先等 3 分鐘。所有分頁共用同一筆紀錄
  const HOUR = 60 * 60 * 1000, FIRST = 3 * 60 * 1000;
  let animal = { win: 0, due: 0 };
  function animalRoll() {
    const now = Date.now();
    if (animal.win && now < animal.win + HOUR) return;
    const win = now;
    const due = Math.random() < .2 ? win + FIRST + Math.random() * (HOUR - FIRST) : 0;
    animal = { win, due };
    chrome.storage.local.set({ animal });
  }
  chrome.storage.local.get({ animal }, s => { animal = s.animal; animalRoll(); setInterval(animalRoll, 30000); });

  // 季節水彩微景：圖片由背景程式取得，畫在 canvas 上
  const art = new Map();
  const loadArt = url => {
    if (!art.has(url)) art.set(url, loadBitmap(url));
    return art.get(url);
  };
  const artCanvas = url => {
    const cv = document.createElement('canvas');
    cv.width = cv.height = 256;
    loadArt(url).then(bmp => cv.getContext('2d').drawImage(bmp, 0, 0, 256, 256)).catch(() => {});
    return cv;
  };
  window.QSeasonStart(stage, {
    css: window.QSeasonCSS,
    load: loadArt,
    canvas: artCanvas,
    animalReady: () => !!animal.due && Date.now() >= animal.due,
    animalShown: () => { animal = { win: animal.win, due: 0 }; chrome.storage.local.set({ animal }); }
  });
  // Alt＋點一下網頁：叫最近的角色過來（攔下 Alt＋點連結的下載行為）
  document.addEventListener('click', e => {
    if (!e.altKey || e.button !== 0 || !host.isConnected) return;
    if (world.callTo(e.clientX)) { e.preventDefault(); e.stopPropagation(); }
  }, true);
  document.addEventListener('fullscreenchange', () => { host.style.display = document.fullscreenElement ? 'none' : ''; });
})();
