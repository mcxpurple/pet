// 擴充功能版：把共用引擎疊在每個網頁最上層
(() => {
  if (window.top !== window || window.__qpet) return;
  window.__qpet = true;

  const send = msg => new Promise((res, rej) => {
    try {
      chrome.runtime.sendMessage(msg, r => {
        if (chrome.runtime.lastError) return rej(chrome.runtime.lastError);
        r && !r.error ? res(r.data) : rej(new Error(r ? r.error : 'no response'));
      });
    } catch (e) { rej(e); }
  });

  // Shadow DOM 疊層，與網頁樣式隔離
  const host = document.createElement('div');
  host.style.cssText = 'all:initial;position:fixed;inset:0;pointer-events:none;z-index:2147483647;';
  const root = host.attachShadow({ mode: 'open' });
  const stage = document.createElement('div');
  root.appendChild(stage);
  const world = new QPet.World(stage);

  // 圖片由背景程式取得後解成點陣圖，不受網頁安全政策影響
  const cache = new Map();
  function loadBitmap(url) {
    if (!cache.has(url)) cache.set(url, send({ type: 'image', url }).then(b64 => {
      const bin = atob(b64), arr = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
      return createImageBitmap(new Blob([arr], { type: 'image/png' }));
    }));
    return cache.get(url);
  }
  async function loadSets(c) {
    const out = {};
    await Promise.all(Object.entries(c.sets).map(async ([s, urls]) => {
      out[s] = (await Promise.all(urls.map(u => loadBitmap(u).catch(() => null)))).filter(Boolean);
    }));
    return out;
  }

  let runId = 0;
  async function apply(s) {
    const id = ++runId;
    world.clear();
    if (!s.enabled || !s.pick.length) { host.remove(); return; }
    let roster;
    try { roster = await send({ type: 'roster' }); } catch { return; }
    const chosen = s.pick.map(i => roster.find(c => c.id === i)).filter(Boolean).slice(0, 2);
    const list = await Promise.all(chosen.map(async c => ({ cfg: c, bitmaps: await loadSets(c) })));
    if (id !== runId) return;
    if (!host.isConnected) document.documentElement.appendChild(host);
    world.set(list);
  }

  const DEF = { pick: [], enabled: true, size: '中' };
  chrome.storage.local.get(DEF, s => { world.setSize(s.size); apply(s); });
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local') return;
    if (ch.size) world.setSize(ch.size.newValue);
    if (ch.pick || ch.enabled) chrome.storage.local.get(DEF, apply);
  });
  document.addEventListener('fullscreenchange', () => { host.style.display = document.fullscreenElement ? 'none' : ''; });
})();
