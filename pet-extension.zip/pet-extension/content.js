// 桌寵引擎（擴充功能版）：疊在每個網頁最上層
(() => {
  if (window.top !== window || window.__qpet) return;
  window.__qpet = true;

  const SPEED = { '慢': 28, '中': 45, '快': 70 };
  const IMAGE_FACES_RIGHT = true;     // 圖片中角色預設面向右；若走路方向相反改為 false
  const ASPECT = 600 / 450;           // 圖片畫布比例（高/寬）
  const GRAVITY = 2200;

  const send = msg => new Promise((res, rej) => {
    try {
      chrome.runtime.sendMessage(msg, r => {
        if (chrome.runtime.lastError) return rej(chrome.runtime.lastError);
        r && !r.error ? res(r.data) : rej(new Error(r ? r.error : 'no response'));
      });
    } catch (e) { rej(e); }
  });

  /* ===== 疊層（Shadow DOM，與網頁樣式隔離） ===== */
  const host = document.createElement('div');
  host.style.cssText = 'all:initial;position:fixed;inset:0;pointer-events:none;z-index:2147483647;';
  const root = host.attachShadow({ mode: 'open' });
  root.innerHTML = `<style>
    .pet{position:absolute;left:0;top:0;pointer-events:auto;cursor:grab;touch-action:none;will-change:transform;}
    .pet.dragging{cursor:grabbing;}
    .pet canvas{display:block;width:100%;height:100%;}
    .fx{position:absolute;pointer-events:none;animation:up 1.4s ease-out forwards;line-height:0;}
    .fx.zzz{animation:zzz 2.4s ease-out forwards;font:700 16px Georgia,serif;color:#9b6fbf;line-height:1;}
    @keyframes up{0%{opacity:0;transform:translate(-50%,0) scale(.6)}20%{opacity:1;transform:translate(-50%,-10px) scale(1)}100%{opacity:0;transform:translate(-50%,-50px) scale(1)}}
    @keyframes zzz{0%{opacity:0;transform:translate(0,0) scale(.6)}25%{opacity:1}100%{opacity:0;transform:translate(18px,-46px) scale(1.15)}}
  </style>`;
  const stage = document.createElement('div');
  root.appendChild(stage);

  /* ===== 特效（程式繪製） ===== */
  const SVG = {
    '愛心': '<svg viewBox="0 0 24 24" width="22" height="22"><path fill="#f07aa0" d="M12 21s-7.5-4.6-9.6-9.2C.9 8.4 3 5 6.4 5c2 0 3.6 1.1 4.6 2.6C12 6.1 13.6 5 15.6 5 19 5 21.1 8.4 21.6 11.8 19.5 16.4 12 21 12 21z"/></svg>',
    '音符': '<svg viewBox="0 0 24 24" width="22" height="22"><path fill="#7aa7f0" d="M9 18.5a3 3 0 1 1-2-2.8V5l12-2v12.5a3 3 0 1 1-2-2.8V6.4l-8 1.4z"/></svg>',
    '驚嘆號': '<svg viewBox="0 0 24 24" width="22" height="22"><rect x="10" y="3" width="4" height="12" rx="2" fill="#f0a23a"/><circle cx="12" cy="19.5" r="2.2" fill="#f0a23a"/></svg>',
    '閃光': '<svg viewBox="0 0 24 24" width="24" height="24"><path fill="#f5c84a" d="M12 2l2.2 7.8L22 12l-7.8 2.2L12 22l-2.2-7.8L2 12l7.8-2.2z"/></svg>'
  };
  function spawnFx(kind, x, y) {
    if (!kind || kind === '無') return;
    const el = document.createElement('div');
    if (kind === 'zzz') { el.className = 'fx zzz'; el.textContent = 'z'; el.style.fontSize = (12 + Math.random() * 8) + 'px'; }
    else { if (!SVG[kind]) return; el.className = 'fx'; el.innerHTML = SVG[kind]; }
    el.style.left = x + 'px'; el.style.top = y + 'px';
    stage.appendChild(el);
    setTimeout(() => el.remove(), 2500);
  }

  /* ===== 圖片：由背景程式取得，解成點陣圖（不受網頁安全政策影響） ===== */
  const bitmapCache = new Map();
  async function loadBitmap(url) {
    if (bitmapCache.has(url)) return bitmapCache.get(url);
    const p = send({ type: 'image', url }).then(b64 => {
      const bin = atob(b64), arr = new Uint8Array(bin.length);
      for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
      return createImageBitmap(new Blob([arr], { type: 'image/png' }));
    });
    bitmapCache.set(url, p);
    return p;
  }
  async function loadSets(c) {
    const sets = {};
    await Promise.all(Object.entries(c.sets).map(async ([s, urls]) => {
      sets[s] = (await Promise.all(urls.map(u => loadBitmap(u).catch(() => null)))).filter(Boolean);
    }));
    return sets;
  }

  /* ===== 桌寵 ===== */
  class Pet {
    constructor(cfg, bitmaps, startX) {
      this.c = cfg; this.b = bitmaps;
      this.h = cfg.size; this.w = cfg.size / ASPECT;
      this.x = startX; this.y = 0; this.vy = 0;
      this.dir = Math.random() < .5 ? 1 : -1;
      this.speed = SPEED[cfg.speed] || SPEED['中'];
      this.mode = 'walk'; this.modeT = 0; this.modeDur = 4 + Math.random() * 4;
      this.lastTouch = performance.now();
      this.meetCool = 0; this.fxT = 0; this.t = 0;
      this.el = document.createElement('div'); this.el.className = 'pet';
      this.el.style.width = this.w + 'px'; this.el.style.height = this.h + 'px';
      this.cv = document.createElement('canvas');
      const dpr = window.devicePixelRatio || 1;
      this.cv.width = Math.round(this.w * dpr); this.cv.height = Math.round(this.h * dpr);
      this.ctx = this.cv.getContext('2d');
      this.el.appendChild(this.cv);
      stage.appendChild(this.el);
      this.y = this.ground();
      this.setImg('idle');
      this.bindInput();
    }
    ground() { return innerHeight - this.h - 4; }
    has(s) { return this.b[s] && this.b[s].length; }
    setImg(state) {
      const list = this.has(state) ? this.b[state] : this.b.idle;
      const pick = list[Math.floor(Math.random() * list.length)];
      if (this.cur === pick) return;
      this.cur = pick;
      this.ctx.clearRect(0, 0, this.cv.width, this.cv.height);
      this.ctx.drawImage(pick, 0, 0, this.cv.width, this.cv.height);
    }
    setMode(m, dur) {
      this.mode = m; this.modeT = 0; this.modeDur = dur || 0;
      const map = { walk: 'idle', stand: 'idle', look: 'idle', meet: 'idle', fall: 'drag' };
      this.setImg(map[m] || m);
    }
    touch() { this.lastTouch = performance.now(); }
    bindInput() {
      let down = null;
      this.el.addEventListener('pointerdown', e => {
        e.preventDefault(); e.stopPropagation();
        this.el.setPointerCapture(e.pointerId);
        down = { x: e.clientX, y: e.clientY, ox: 0, oy: 0, moved: false };
      });
      this.el.addEventListener('pointermove', e => {
        if (!down) return;
        if (!down.moved && Math.hypot(e.clientX - down.x, e.clientY - down.y) > 6) {
          down.moved = true; this.wake(); this.setMode('drag'); this.el.classList.add('dragging');
          down.ox = this.w / 2; down.oy = this.h * 0.12;
        }
        if (down.moved) { this.x = e.clientX - down.ox; this.y = e.clientY - down.oy; this.touch(); }
      });
      const up = e => {
        if (!down) return;
        e && e.stopPropagation();
        if (down.moved) { this.el.classList.remove('dragging'); this.vy = 0; this.setMode('fall'); }
        else this.onClick();
        down = null; this.touch();
      };
      this.el.addEventListener('pointerup', up);
      this.el.addEventListener('pointercancel', up);
      this.el.addEventListener('click', e => e.stopPropagation());
    }
    onClick() {
      this.wake(); this.touch();
      this.setMode('click', 1.2);
      spawnFx(this.c.effect_click, this.x + this.w / 2, this.y + 4);
    }
    wake() { if (this.mode === 'sleep') this.setMode('stand', 1); }
    update(dt, other) {
      this.t += dt; this.modeT += dt; this.meetCool -= dt;
      const g = this.ground();
      let bob = 0, tilt = 0, sy = 1;
      switch (this.mode) {
        case 'walk':
          this.x += this.dir * this.speed * dt;
          if (this.x < 0) { this.x = 0; this.dir = 1; }
          if (this.x > innerWidth - this.w) { this.x = innerWidth - this.w; this.dir = -1; }
          bob = -Math.abs(Math.sin(this.t * 9)) * 5;
          tilt = Math.sin(this.t * 9) * 2;
          if (this.modeT > this.modeDur) this.idleChoice();
          break;
        case 'stand':
          sy = 1 + Math.sin(this.t * 2.2) * 0.012;
          if (this.modeT > this.modeDur) this.idleChoice();
          break;
        case 'click':
          bob = -Math.sin(Math.min(this.modeT / (this.has('click') ? .35 : .4), 1) * Math.PI) * (this.has('click') ? 8 : 18);
          if (this.modeT > this.modeDur) this.setMode('walk', 3 + Math.random() * 4);
          break;
        case 'drag':
          tilt = Math.sin(this.t * 6) * (this.has('drag') ? 3 : 8);
          break;
        case 'fall':
          this.vy += GRAVITY * dt; this.y += this.vy * dt;
          if (this.y >= g) { this.y = g; this.vy = 0; this.setMode('stand', 1 + Math.random()); }
          break;
        case 'sleep':
          sy = 1 + Math.sin(this.t * 1.4) * 0.015;
          if (!this.has('sleep')) tilt = 6;
          this.fxT -= dt;
          if (this.fxT <= 0 && this.c.effect_sleep !== '無') { this.fxT = 1.1; spawnFx('zzz', this.x + this.w * .68, this.y + this.h * .12); }
          break;
        case 'meet':
          if (other) this.dir = other.x > this.x ? 1 : -1;
          if (this.modeT > this.modeDur) {
            this.meetCool = 12;
            const away = other ? (other.x > this.x ? -1 : 1) : this.dir;
            this.setMode('walk', 3 + Math.random() * 3); this.dir = away;
          }
          break;
        case 'look':
          if (other) this.dir = other.x > this.x ? 1 : -1;
          if (!other || (other.mode !== 'drag' && other.mode !== 'fall')) this.setMode('stand', 1.5);
          break;
        default:
          if (this.modeT > this.modeDur) this.setMode('walk', 3 + Math.random() * 4);
      }
      if (!['drag', 'fall'].includes(this.mode)) this.y = g;
      if ((performance.now() - this.lastTouch) / 1000 > this.c.sleep_after && ['walk', 'stand'].includes(this.mode)) {
        this.setMode('sleep'); this.fxT = .4;
      }
      const flip = (this.dir === 1) === IMAGE_FACES_RIGHT ? 1 : -1;
      this.el.style.transformOrigin = this.mode === 'drag' ? '50% 12%' : '50% 100%';
      this.el.style.transform = `translate(${this.x}px,${this.y + bob}px) rotate(${tilt}deg) scale(${flip},${sy})`;
      this.el.style.zIndex = this.mode === 'drag' ? 10 : 1;
    }
    idleChoice() {
      const r = Math.random();
      const extras = (this.c.extras || []).filter(n => this.has(n));
      if (extras.length && r < .25) this.setMode(extras[Math.floor(Math.random() * extras.length)], 4 + Math.random() * 4);
      else if (r < .55) this.setMode('stand', 1.5 + Math.random() * 3);
      else { if (Math.random() < .4) this.dir *= -1; this.setMode('walk', 3 + Math.random() * 5); }
    }
    destroy() { this.el.remove(); }
  }

  function interact(a, b) {
    for (const [p, q] of [[a, b], [b, a]]) {
      if (p.mode === 'drag' && ['walk', 'stand', 'meet'].includes(q.mode)) q.setMode('look');
    }
    const close = Math.abs((a.x + a.w / 2) - (b.x + b.w / 2)) < (a.w + b.w) * .45;
    if (close && a.mode === 'walk' && b.mode === 'walk' && a.meetCool <= 0 && b.meetCool <= 0) {
      const dur = 2.5 + Math.random() * 1.5;
      a.setMode('meet', dur); b.setMode('meet', dur); a.touch(); b.touch();
      const mx = (a.x + a.w / 2 + b.x + b.w / 2) / 2, my = Math.min(a.y, b.y) + 10;
      spawnFx('閃光', mx, my);
      setTimeout(() => spawnFx('閃光', mx + 14, my + 18), 350);
    }
  }

  /* ===== 主迴圈 ===== */
  const pets = [];
  let raf = 0, last = 0;
  function loop(now) {
    const dt = Math.min((now - last) / 1000, .05); last = now;
    pets.forEach((p, i) => p.update(dt, pets[1 - i]));
    if (pets.length === 2) interact(pets[0], pets[1]);
    raf = requestAnimationFrame(loop);
  }

  let runId = 0;
  async function apply(settings) {
    const id = ++runId;
    pets.splice(0).forEach(p => p.destroy());
    cancelAnimationFrame(raf);
    if (!settings.enabled || !settings.pick.length) { host.remove(); return; }
    let roster;
    try { roster = await send({ type: 'roster' }); } catch { return; }
    const chosen = settings.pick.map(i => roster.find(c => c.id === i)).filter(Boolean).slice(0, 2);
    const loaded = await Promise.all(chosen.map(async c => ({ c, b: await loadSets(c) })));
    if (id !== runId) return;
    if (!host.isConnected) document.documentElement.appendChild(host);
    loaded.filter(x => x.b.idle && x.b.idle.length).forEach((x, i, arr) => {
      const slot = innerWidth / (arr.length + 1) * (i + 1);
      pets.push(new Pet(x.c, x.b, slot - (x.c.size / ASPECT) / 2));
    });
    last = performance.now();
    raf = requestAnimationFrame(loop);
  }

  const DEF = { pick: [], enabled: true };
  chrome.storage.local.get(DEF, s => apply(s));
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== 'local' || (!ch.pick && !ch.enabled)) return;
    chrome.storage.local.get(DEF, s => apply(s));
  });
  addEventListener('resize', () => pets.forEach(p => { if (p.x > innerWidth - p.w) p.x = Math.max(0, innerWidth - p.w); }));
  document.addEventListener('fullscreenchange', () => { host.style.display = document.fullscreenElement ? 'none' : ''; });
})();
