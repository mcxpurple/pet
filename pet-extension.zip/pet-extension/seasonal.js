window.QSeasonCSS = "/* Violet Hour 紫夜星光｜網頁版季節水彩微景與夏夜螢火蟲\n * 只供 index.html 載入，並不修改 Chrome 擴充功能。\n * 粒子 z-index:-1、動物 z-index:0、引擎角色 z-index:1。\n */\n.qseason-particle {\n  position:absolute;\n  z-index:-1;\n  pointer-events:none;\n  user-select:none;\n  line-height:1;\n  opacity:0;\n  transform:translate3d(-50%,0,0);\n  animation:qseason-scatter var(--duration,3400ms) ease-out forwards;\n  will-change:transform,opacity;\n}\n.qseason-sprite {\n  display:block;\n  object-fit:contain;\n  -webkit-user-drag:none;\n}\n.qseason-ground {\n  animation-name:qseason-ground-fade;\n}\n/* Outer element: drifting curved path plus gentle banking. */\n.qseason-flight {\n  animation-name:qseason-curved-flight;\n}\n/* Inner PNG: its own independent rotation for the entire lifetime. */\n.qseason-art-spin {\n  display:block;\n  width:100%;\n  height:100%;\n  object-fit:contain;\n  transform-origin:center center;\n  animation:qseason-image-spin var(--duration,4500ms) linear both;\n  will-change:transform;\n}\n.qseason-firefly {\n  border-radius:50%;\n  background:#ffed9b;\n  box-shadow:0 0 var(--glow-blur,5px) var(--glow-spread,2px) rgba(255,233,123,.68),\n    0 0 var(--glow-halo,12px) var(--glow-halo-spread,3px) rgba(246,242,145,.34);\n  animation-name:qseason-firefly;\n}\n@keyframes qseason-scatter {\n  0% {opacity:0;transform:translate3d(-50%,0,0) rotate(0deg) scale(.75)}\n  17% {opacity:var(--peak-opacity,.8)}\n  75% {opacity:calc(var(--peak-opacity,.8) * .55)}\n  100% {opacity:0;transform:translate3d(calc(-50% + var(--dx,0px)),var(--dy,-30px),0) rotate(var(--rotation,0deg)) scale(1)}\n}\n/* The position changes direction several times, rather than following one straight line. */\n@keyframes qseason-curved-flight {\n  0% {opacity:0;transform:translate3d(-50%,0,0) rotate(var(--flight-turn0,0deg)) scale(.75)}\n  25% {opacity:var(--peak-opacity,.8);transform:translate3d(calc(-50% + var(--path-x1,0px)),var(--path-y1,-40px),0) rotate(var(--flight-turn1,12deg)) scale(.85)}\n  50% {opacity:var(--peak-opacity,.8);transform:translate3d(calc(-50% + var(--path-x2,0px)),var(--path-y2,-80px),0) rotate(var(--flight-turn2,-7deg)) scale(.93)}\n  75% {opacity:calc(var(--peak-opacity,.8) * .55);transform:translate3d(calc(-50% + var(--path-x3,0px)),var(--path-y3,-120px),0) rotate(var(--flight-turn3,9deg)) scale(.98)}\n  100% {opacity:0;transform:translate3d(calc(-50% + var(--dx,0px)),var(--dy,-160px),0) rotate(var(--flight-turn4,0deg)) scale(1)}\n}\n@keyframes qseason-image-spin {\n  0% {transform:rotate(var(--self-start,0deg))}\n  100% {transform:rotate(var(--self-end,360deg))}\n}\n@keyframes qseason-ground-fade {\n  0% {opacity:0;transform:translate3d(-50%,0,0) scale(.85)}\n  23% {opacity:var(--peak-opacity,.8)}\n  70% {opacity:var(--peak-opacity,.8)}\n  100% {opacity:0;transform:translate3d(-50%,0,0) scale(.92)}\n}\n@keyframes qseason-firefly {\n  0% {opacity:0;transform:translate3d(-50%,0,0) scale(.65)}\n  20% {opacity:.92}\n  44% {opacity:.30}\n  68% {opacity:.82}\n  100% {opacity:0;transform:translate3d(calc(-50% + var(--dx,0px)),var(--dy,-26px),0) scale(.75)}\n}\n@media (prefers-reduced-motion:reduce) {\n  .qseason-particle {animation:none;display:none}\n}\n\n/* 彩蛋動物：在桌寵後方（引擎角色 z-index:1），粒子前方（-1）。 */\n.qseason-animal {\n  position:absolute;\n  z-index:0;\n  display:block;\n  object-fit:contain;\n  opacity:0;\n  pointer-events:auto;\n  cursor:pointer;\n  user-select:none;\n  -webkit-user-drag:none;\n  touch-action:manipulation;\n  transform-origin:50% 92%;\n  will-change:transform,opacity;\n}\n.qseason-heart {\n  position:absolute;\n  z-index:2;\n  pointer-events:none;\n  font-size:24px;\n  line-height:1;\n  color:#ee8198;\n  text-shadow:0 1px 3px rgba(70,36,49,.25);\n}\n@media (prefers-reduced-motion:reduce) {\n  .qseason-animal,.qseason-heart {animation:none;display:none}\n}\n";
/*
 * Violet Hour 紫夜星光｜季節水彩微景（擴充功能版）
 * © 2026 mcx_purple. All rights reserved.
 * 由網頁版 seasonal-micro-scene.js 自動移植（tools 見 CHANGELOG 2026-11-13）。
 * 差異：圖片由背景程式取得後畫在 canvas（不受網站安全政策阻擋）；
 *       動物彩蛋的每小時抽選存在 chrome.storage，所有分頁共用；樣式注入 Shadow DOM。
 */
window.QSeasonStart = function (stage, ext) {
  'use strict';

  const BOTTOM_ZONE = 125;
  const PARTICLE_MIN_MS = 4000;
  const PARTICLE_MAX_MS = 5500;
  // Responsive density, recalculated every tick (including when the viewport is resized).
  // The cap is shared by all pets; it is never multiplied by the number of pets.
  function particleSettings() {
    const width = window.innerWidth;
    if (width <= 600) return { max: 6, minMs: 800, maxMs: 1200 };
    if (width <= 1100) return { max: 8, minMs: 650, maxMs: 950 };
    if (width <= 1600) return { max: 10, minMs: 500, maxMs: 850 };
    return { max: 12, minMs: 450, maxMs: 750 };
  }
  const random = (a, b) => a + Math.random() * (b - a);
  const choose = a => a[Math.floor(Math.random() * a.length)];
  const live = new Set();
  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');
  const requestedSeason = null;
  const allowedSeasons = ['spring', 'summer', 'autumn', 'winter', 'firefly'];
  const seasonOverride = allowedSeasons.includes(requestedSeason) ? requestedSeason : null;
  const ROOT = 'https://mcxpurple.github.io/pet/assets/seasonal/';

  // 動物彩蛋：開始散步後 3 分鐘第一次抽選，此後每 60 分鐘抽一次。
  // 時鐘只累計分頁可見的時間；機率只影響本小時是否排入一次出場。
  const ANIMAL_CHANCE = 0.2;
  const ANIMAL_INTERVAL_MIN = 60;
  const ANIMAL_FIRST_DELAY_MS = 3 * 60 * 1000;
  const ANIMAL_INTERVAL_MS = ANIMAL_INTERVAL_MIN * 60 * 1000;
  const animalOverride = false;
  // 動物彩蛋：不分季節，每次出場隨機抽一隻。
  // 正式清單在 assets/seasonal/animals.json（網頁版與擴充功能每次開啟時讀取，新增動物不用重裝）。
  // 新增動物：PNG 放進 assets/seasonal/animals/，在 animals.json 加一筆：
  //   file：檔名（不含 .png，英數小寫與連字號）
  //   move：出場方式 magpie 跳跳再飛走｜deer 走進來低頭再走掉｜cat 悄悄靠近再衝走｜bear 坐著晃一晃
  //   foot：圖片底部透明留白占圖高的比例，讓腳貼齊地面（不確定先填 0.1）
  // 下面是讀不到 animals.json 時的備用清單。
  const ANIMAL_MOVES = ['magpie', 'deer', 'cat', 'bear'];
  const ANIMAL_FALLBACK = [
    { file: 'taiwan-blue-magpie', move: 'magpie', foot: .15 },
    { file: 'taiwan-sika-deer', move: 'deer', foot: .07 },
    { file: 'leopard-cat', move: 'cat', foot: .15 },
    { file: 'formosan-black-bear', move: 'bear', foot: .045 }
  ];
  const fetchJSON = url => ext.json(url);
  const ANIMAL_INFO = {};
  function cleanAnimals(list) {
    if (!Array.isArray(list)) return [];
    return list.filter(a => a && /^[a-z0-9-]+$/.test(a.file) && ANIMAL_MOVES.includes(a.move))
      .map(a => ({ file: a.file, move: a.move, foot: Math.min(.5, Math.max(0, Number(a.foot) || .1)) }));
  }


  // group: partial ≈ 75%，full ≈ 25%；ground 為不飄升的蒲公英絨球。
  const sprite = (folder, file, group, weight = 1) => ({
    file: ROOT + folder + '/' + file + '.png', group, weight
  });
  const shared = (file, group) => ({ file: ROOT + file + '.png', group, weight: 1 });
  const dandelion = [
    shared('dandelion-seed', 'partial'),
    shared('dandelion-puff', 'ground')
  ];
  const CAMELLIA = [
    sprite('winter', 'camellia-full', 'full'),
    sprite('winter', 'camellia-petal', 'partial')
  ];
  const CONFIG = {
    plum: [
      sprite('winter', 'plum-full', 'full'),
      sprite('winter', 'plum-petal', 'partial'),
      ...CAMELLIA
    ],
    cherry: [
      sprite('spring', 'taiwan-cherry-full', 'full'),
      sprite('spring', 'taiwan-cherry-petal', 'partial'),
      sprite('spring', 'taiwan-azalea-full', 'full'),
      sprite('spring', 'taiwan-azalea-petal', 'partial'),
      sprite('spring', 'taiwan-lily-full', 'full'),
      sprite('spring', 'taiwan-lily-petal', 'partial'),
      ...dandelion
    ],
    tung: [
      sprite('spring', 'tung-flower-full', 'full', 5),
      sprite('spring', 'tung-flower-petal', 'partial', 5),
      sprite('spring', 'taiwan-lily-full', 'full'),
      sprite('spring', 'taiwan-lily-petal', 'partial'),
      ...dandelion
    ],
    summer: [
      sprite('summer', 'poinciana-full', 'full'),
      sprite('summer', 'poinciana-petal', 'partial'),
      sprite('summer', 'lotus-full', 'full'),
      sprite('summer', 'lotus-petal', 'partial'),
      sprite('summer', 'daylily-full', 'full'),
      sprite('summer', 'daylily-petal', 'partial'),
      sprite('summer', 'hibiscus-full', 'full'),
      sprite('summer', 'hibiscus-petal', 'partial'),
      ...dandelion
    ],
    autumn: [
      sprite('autumn', 'maple-leaf', 'full'),
      sprite('autumn', 'maple-fragment', 'partial'),
      sprite('autumn', 'ginkgo-leaf', 'full'),
      // ginkgo-fragment.png 尚未上傳：不列入 preload，也不發出 404。
      sprite('autumn', 'taiwan-rain-tree-flower', 'full'),
      sprite('autumn', 'taiwan-rain-tree-pod', 'full'),
      sprite('autumn', 'silvergrass-plume', 'full'),
      sprite('autumn', 'silvergrass-fluff', 'partial'),
      ...dandelion
    ],
    snow: [
      sprite('winter', 'snowflake', 'full'),
      sprite('winter', 'snowflake-fragment', 'partial'),
      sprite('winter', 'snowball-small', 'full'),
      ...CAMELLIA
      // snowball.png（大）保留在素材庫，暫不使用。
    ]
  };

  function themeNow() {
    if (seasonOverride) {
      return ({ spring: 'cherry', summer: 'summer', autumn: 'autumn',
        winter: 'snow', firefly: 'firefly' })[seasonOverride];
    }
    const now = new Date(), month = now.getMonth() + 1, h = now.getHours();
    if (month <= 2) return 'plum';
    if (month <= 4) return 'cherry';
    if (month === 5) return 'tung';
    if (month <= 8) return h >= 19 || h < 6 ? 'firefly' : 'summer';
    if (month <= 11) return 'autumn';
    return 'snow';
  }

  function ExtImage() { this.naturalWidth = 0; this.onload = null; this.onerror = null; this._src = ''; }
  Object.defineProperty(ExtImage.prototype, 'src', {
    get() { return this._src; },
    set(url) {
      this._src = url;
      ext.load(url).then(bmp => { this.naturalWidth = bmp.width; this.onload && this.onload(); })
        .catch(() => { this.onerror && this.onerror(); });
    }
  });

  let activeTheme = '';
  let animalImage = null;
  let animalSpecies = '';
  let animalLoadSerial = 0;
  let currentAnimal = null;

  // 2026-11-13：四種動物不分季節，每次出場隨機抽一隻。四張圖都很小，第一次就全部預載。
  const animalPool = {};
  function preloadSeasonAnimal() {
    if (animalLoadSerial) return;
    animalLoadSerial = 1;
    fetchJSON(ROOT + 'animals.json').then(cleanAnimals).catch(() => [])
      .then(list => preloadAnimals(list.length ? list : ANIMAL_FALLBACK));
  }
  function preloadAnimals(list) {
    list.forEach(a => { ANIMAL_INFO[a.file] = a; });
    list.map(a => a.file).forEach(species => {
      const preload = new ExtImage();
      preload.onload = () => {
        if (preload.naturalWidth > 0) { animalPool[species] = preload; if (!animalImage) pickAnimal(); }
      };
      preload.src = ROOT + 'animals/' + species + '.png';
    });
  }
  function pickAnimal() {
    const list = Object.keys(animalPool);
    if (!list.length) return false;
    animalSpecies = choose(list);
    animalImage = animalPool[animalSpecies];
    return true;
  }

  let loaded = { full: [], partial: [], ground: [] };
  let loadingSerial = 0;
  // 只對當季檔案建立 Image。失敗者不進候選清單；換季後忽略舊 onload。
  function updateSeasonAssets(theme) {
    if (activeTheme === theme) return;
    activeTheme = theme;
    preloadSeasonAnimal(theme);
    const serial = ++loadingSerial;
    loaded = { full: [], partial: [], ground: [] };
    clearParticles();
    if (theme === 'firefly') return;
    (CONFIG[theme] || []).forEach(item => {
      const preload = new ExtImage();
      preload.onload = () => {
        if (loadingSerial === serial && preload.naturalWidth > 0) {
          loaded[item.group].push(item);
        }
      };
      preload.onerror = () => {
        // 載入失敗時從候選清單自然排除；不回退至 emoji 或其他品種。
        if (loadingSerial === serial) {
          for (const group of Object.keys(loaded)) {
            loaded[group] = loaded[group].filter(candidate => candidate.file !== item.file);
          }
        }
      };
      preload.src = item.file;
    });
  }

  function chooseWeighted(items) {
    const total = items.reduce((n, item) => n + item.weight, 0);
    let roll = random(0, total);
    for (const item of items) {
      roll -= item.weight;
      if (roll <= 0) return item;
    }
    return items[items.length - 1];
  }

  // 獨立特效層，只依 DOM 讀取角色尺寸和位置，不讀寫 World / Pet 狀態。
  function spawn(stage, type, pet) {
    const rect = pet.getBoundingClientRect();
    const width = window.innerWidth, height = window.innerHeight;
    if (rect.width <= 0 || rect.bottom < height - BOTTOM_ZONE || rect.top > height) return;
    const petHeight = pet.offsetHeight || rect.height;
    const relativeSize = (low, high, minPx, maxPx) =>
      Math.min(maxPx, Math.max(minPx, petHeight * random(low, high)));

    let el, size, ground = false, item = null, pale = false;
    if (type === 'firefly') {
      el = document.createElement('span');
      el.className = 'qseason-particle qseason-firefly';
      // Mostly tiny glimmers, occasionally larger glowing fireflies.
      size = Math.random() < .70 ? random(2.5, 4.7) : random(4.8, 7.5);
      // Scale each halo with its firefly, so small dots stay visibly smaller.
      el.style.setProperty('--glow-blur', (size * .95).toFixed(1) + 'px');
      el.style.setProperty('--glow-spread', (size * .30).toFixed(1) + 'px');
      el.style.setProperty('--glow-halo', (size * 2.2).toFixed(1) + 'px');
      el.style.setProperty('--glow-halo-spread', (size * .45).toFixed(1) + 'px');
    } else {
      if (loaded.ground.length && Math.random() < .08) {
        item = chooseWeighted(loaded.ground);
        ground = true;
      } else {
        const preferred = Math.random() < .75 ? 'partial' : 'full';
        const candidates = loaded[preferred].length ? loaded[preferred]
          : loaded[preferred === 'partial' ? 'full' : 'partial'];
        if (!candidates.length) return;
        item = chooseWeighted(candidates);
      }
      // Two independent layers: outer container follows a curved flight path,
      // inner PNG spins on its own axis throughout the same 4–5.5 second flight.
      // Grounded dandelion puffs remain as a single stationary image.
      el = ground ? ext.canvas(item.file) : document.createElement('span');
      el.className = ground
        ? 'qseason-particle qseason-sprite qseason-ground'
        : 'qseason-particle qseason-flight';
      el.style.pointerEvents = 'none';
      if (ground) {
        el.draggable = false;
      } else {
        const artwork = ext.canvas(item.file);
        artwork.className = 'qseason-sprite qseason-art-spin';
        artwork.draggable = false;
        artwork.style.pointerEvents = 'none';
        el.appendChild(artwork);
      }
      pale = /(?:tung-flower|taiwan-lily|taiwan-azalea|lotus|snowflake|plum-|dandelion-)/.test(item.file);
      size = ground ? relativeSize(.11, .15, 19, 32)
        : item.group === 'full' ? relativeSize(.13, .17, 22, 36)
        : relativeSize(.095, .135, 17, 28);
      // Transparent padding around pale PNGs makes their actual flowers appear small.
      // Enlarge their rendered boxes slightly, without changing or outlining the artwork.
      if (pale && !ground) size = Math.min(41, size * 1.12);
    }

    const x = Math.max(14, Math.min(width - 14, rect.left + rect.width * random(.17, .83)));
    const y = ground
      ? Math.max(height - BOTTOM_ZONE, Math.min(height - size - 4, rect.bottom - size - random(2, 8)))
      : Math.max(height - BOTTOM_ZONE, Math.min(height - 6, rect.bottom - random(8, 20)));
    const duration = random(PARTICLE_MIN_MS, PARTICLE_MAX_MS);
    el.style.left = x + 'px';
    el.style.top = y + 'px';
    el.style.width = size + 'px';
    el.style.height = size + 'px';
    el.style.setProperty('--duration', duration + 'ms');
    el.style.setProperty('--peak-opacity',
      random(pale ? .95 : .80, pale ? 1 : .95).toFixed(2));
    const isSeed = !!item && item.file.endsWith('/dandelion-seed.png');
    const drift = isSeed ? 72 : type === 'firefly' ? 65 : 42;
    const dx = random(-drift, drift);
    el.style.setProperty('--dx', dx.toFixed(1) + 'px');
    const rise = type === 'firefly'
      ? Math.min(400, Math.max(75, petHeight * random(.85, 1.70)))
      : isSeed
        ? Math.min(400, Math.max(110, petHeight * random(1.20, 1.80)))
        : Math.min(285, Math.max(70, petHeight * random(.70, 1.20)));
    el.style.setProperty('--dy', (-rise).toFixed(1) + 'px');
    if (item && !ground) {
      // Layer 1: an independently curved flight path, with changing direction
      // and gentle banking while travelling outward / upward.
      const curveDirection = Math.random() < .5 ? -1 : 1;
      const curve = random(10, Math.min(34, Math.max(10, width * .04)));
      const pathPositions = [
        dx * .24 + curveDirection * curve,
        dx * .51 - curveDirection * curve * .55,
        dx * .76 + curveDirection * curve * .40
      ];
      const pathHeights = [.25, .52, .78];
      pathPositions.forEach((pos, index) => {
        const step = index + 1;
        el.style.setProperty('--path-x' + step, pos.toFixed(1) + 'px');
        el.style.setProperty('--path-y' + step,
          (-(rise * pathHeights[index])).toFixed(1) + 'px');
      });
      const bank = random(12, 30) * curveDirection;
      const pathStart = random(-20, 20);
      for (let step = 0; step <= 4; step++) {
        const turn = [pathStart, pathStart + bank,
          pathStart - bank * .6, pathStart + bank * .55,
          pathStart + bank * .25][step];
        el.style.setProperty('--flight-turn' + step, turn.toFixed(1) + 'deg');
      }

      // Layer 2: the PNG itself rotates independently of the flight path.
      // Loose petals, leaf fragments, drifting seeds and fluff spin more than
      // complete blossoms or leaves. Each gets a random direction and angle.
      const artwork = el.firstChild;
      const rapid = item.group === 'partial';
      const direction = Math.random() < .5 ? -1 : 1;
      const spinStart = random(-110, 110);
      const sweep = direction * (rapid ? random(360, 900) : random(180, 420));
      artwork.style.setProperty('--self-start', spinStart.toFixed(1) + 'deg');
      artwork.style.setProperty('--self-end',
        (spinStart + sweep).toFixed(1) + 'deg');
    } else {
      // CSS fireflies retain their original untouched light-particle animation.
      // Dandelion puffs remain grounded with no flying or spinning.
      el.style.setProperty('--rotation', random(-28, 28).toFixed(1) + 'deg');
    }
    // 新 DOM 先插入。z-index 由 CSS 保證：粒子 -1，動物 0，桌寵引擎 1。
    stage.insertBefore(el, stage.firstChild);
    live.add(el);
    window.setTimeout(() => { el.remove(); live.delete(el); }, duration + 100);
  }

  function clearParticles() {
    live.forEach(el => el.remove());
    live.clear();
  }


  // 動物是獨立彩蛋，不佔 MAX_PARTICLES，圖層位於粒子與桌寵之間。
  function spawnAnimal(stage, forced) {
    if (currentAnimal || !pickAnimal()) return false;
    const pets = Array.from(stage.querySelectorAll('.qpet')).filter(p => {
      const r = p.getBoundingClientRect();
      return r.width > 0 && r.bottom >= window.innerHeight - BOTTOM_ZONE &&
        r.top <= window.innerHeight && !p.classList.contains('dragging');
    });
    if (!pets.length) return false;

    const pet = choose(pets);
    const rect = pet.getBoundingClientRect();
    const petHeight = pet.offsetHeight || rect.height;
    const size = petHeight * .50;
    const species = animalSpecies;
    const kind = ANIMAL_INFO[species].move;
    const side = Math.random() < .5 ? 1 : -1;
    const face = side === 1 ? -1 : 1; // 三種側面動物原圖朝左，翻轉後朝右。
    const width = window.innerWidth;
    const height = window.innerHeight;
    const from = side === 1 ? -size - 20 : width + 20;
    const to = side === 1 ? width + size + 20 : -size - 20;
    const stop = side === 1 ? width * .34 - size * .5 : width * .66 - size * .5;

    const el = ext.canvas(animalImage.src);
    el.draggable = false;
    el.className = 'qseason-animal qseason-animal-' + kind;
    el.style.width = size + 'px';
    el.style.height = size + 'px';
    // 原圖留有透明底邊；按實際四張素材修正，讓可見的腳貼近地面。
    el.style.bottom = (4 - size * ANIMAL_INFO[species].foot) + 'px';

    function frame(offset, x, y, facing, opacity = 1, rotate = 0, scaleY = 1) {
      return {
        offset, opacity,
        transform: 'translate3d(' + x.toFixed(1) + 'px,' + y.toFixed(1) +
          'px,0) rotate(' + rotate + 'deg) scaleX(' + facing +
          ') scaleY(' + scaleY + ')'
      };
    }
    const at = ratio => from + (stop - from) * ratio;
    let frames, duration;
    if (kind === 'magpie') {
      // 四次小拋物線彈跳，停下左右張望，最後斜上方飛離。
      duration = 9300;
      frames = [
        frame(0, from, 0, face, 0),
        frame(.07, at(.18), -size*.15, face),
        frame(.13, at(.30), 0, face),
        frame(.18, at(.46), -size*.14, face),
        frame(.24, at(.56), 0, face),
        frame(.29, at(.72), -size*.13, face),
        frame(.34, at(.80), 0, face),
        frame(.39, at(.94), -size*.12, face),
        frame(.45, stop, 0, face),
        frame(.55, stop, 0, -face),
        frame(.64, stop, 0, face),
        frame(.73, stop, 0, face),
        frame(1, to, -height-size, face, 0, side*12)
      ];
    } else if (kind === 'deer') {
      // 走入、低頭約兩秒、繼續走出另一側。
      duration = 9500;
      frames = [
        frame(0, from, 0, face, 0),
        frame(.09, at(.25), -2, face),
        frame(.18, at(.46), 1, face),
        frame(.29, at(.76), -2, face),
        frame(.39, stop, 0, face),
        frame(.44, stop, size*.055, face, 1, side*11),
        frame(.65, stop, size*.055, face, 1, side*11),
        frame(.69, stop, 0, face),
        frame(.81, stop+(to-stop)*.43, -2, face),
        frame(.90, stop+(to-stop)*.72, 1, face),
        frame(1, to, 0, face, 0)
      ];
    } else if (kind === 'cat') {
      // 壓低慢速潛入、停兩秒、迅速衝離。
      duration = 7500;
      frames = [
        frame(0, from, size*.06, face, 0, 0, .90),
        frame(.18, at(.47), size*.06, face, 1, 0, .90),
        frame(.36, stop, size*.08, face, 1, 0, .88),
        frame(.64, stop, size*.08, face, 1, 0, .88),
        frame(.70, stop, size*.02, face),
        frame(.87, stop+(to-stop)*.70, -size*.04, face),
        frame(1, to, -size*.04, face, 0)
      ];
    } else {
      // 黑熊原圖正面坐姿，不翻面；邊緣淡入，左右輕晃後淡出。
      duration = 7500;
      const edge = side === 1 ? Math.max(8, width*.075) :
        Math.max(8, width-size-width*.075);
      frames = [
        frame(0, edge, 0, 1, 0),
        frame(.12, edge, 0, 1),
        frame(.26, edge, 0, 1, 1, -5),
        frame(.40, edge, 0, 1, 1, 5),
        frame(.54, edge, 0, 1, 1, -5),
        frame(.68, edge, 0, 1, 1, 5),
        frame(.82, edge, 0, 1),
        frame(1, edge, 0, 1, 0)
      ];
    }

    // 測試模式立即進場，展示 3 秒後結束，正式模式播放各物種 6–12 秒。
    if (forced) {
      duration = 3000;
      const holdX = kind === 'bear' ? (side === 1 ? width*.075 : width-size-width*.075) : stop;
      frames = [
        frame(0, holdX, 0, kind === 'bear' ? 1 : face, 0),
        frame(.20, holdX, 0, kind === 'bear' ? 1 : face),
        frame(.75, holdX, 0, kind === 'bear' ? 1 : face),
        frame(1, holdX, -8, kind === 'bear' ? 1 : face, 0)
      ];
    }

    const instance = { el, animation: null, leaving: false };
    currentAnimal = instance;
    stage.insertBefore(el, stage.firstChild);
    const animation = el.animate(frames, { duration, easing: 'linear', fill: 'forwards' });
    instance.animation = animation;
    const cleanup = () => {
      el.remove();
      if (currentAnimal === instance) currentAnimal = null;
    };
    animation.onfinish = cleanup;

    function earlyLeave() {
      if (instance.leaving || currentAnimal !== instance) return;
      instance.leaving = true;
      const transform = window.getComputedStyle(el).transform;
      const opacity = window.getComputedStyle(el).opacity;
      animation.onfinish = null;
      animation.cancel();
      const exit = el.animate([
        { transform, opacity },
        { transform: transform + ' translateY(-18px)', opacity: 0 }
      ], { duration: 550, easing: 'ease-out', fill: 'forwards' });
      instance.animation = exit;
      exit.onfinish = cleanup;
    }
    el.addEventListener('pointerdown', e => e.stopPropagation());
    el.addEventListener('click', e => {
      e.preventDefault();
      e.stopPropagation();
      const box = el.getBoundingClientRect();
      const heart = document.createElement('span');
      heart.className = 'qfx emo qseason-heart';
      heart.textContent = '❤';
      heart.style.left = (box.left + box.width*.5) + 'px';
      heart.style.top = (box.top + box.height*.25) + 'px';
      stage.appendChild(heart);
      window.setTimeout(() => heart.remove(), 1500);
      earlyLeave();
    });
    return true;
  }

  function pauseAnimalIfHidden(hidden) {
    if (!currentAnimal || !currentAnimal.animation) return;
    if (hidden) currentAnimal.animation.pause();
    else currentAnimal.animation.play();
  }

  function removeAnimal() {
    if (currentAnimal) {
      currentAnimal.animation.onfinish = null;
      currentAnimal.animation.cancel();
      currentAnimal.el.remove();
      currentAnimal = null;
    }
  }

  function init() {
    if (!stage) return;


    // 單調可見時鐘：hidden 狀態不累計，也不因背景計時器延遲而補時。
    let startedWalking = false;
    let visibleMs = 0;
    let lastSample = performance.now();
    let wasVisible = !document.hidden;
    let nextDrawAt = ANIMAL_FIRST_DELAY_MS;
    const animalQueue = [];
    let forcedShown = false;

    function animalBlocked() {
      const picker = null;
      return !stage.isConnected || document.hidden || reducedMotion.matches ||
        (picker && !picker.hidden) ||
        !!stage.querySelector('.qpet.dragging') ||
        !stage.querySelector('.qpet');
    }

    function animalTick() {
      const now = performance.now();
      if (startedWalking && wasVisible) visibleMs += Math.max(0, now - lastSample);
      lastSample = now;
      wasVisible = !document.hidden;
      if (!startedWalking) {
        const picker = null;
        if (stage.querySelector('.qpet') && (!picker || picker.hidden) && !document.hidden) {
          startedWalking = true;
          visibleMs = 0;
        }
      }
      if (!startedWalking || document.hidden) return;

      if (animalOverride) {
        if (!forcedShown && !animalBlocked() && spawnAnimal(stage, true)) forcedShown = true;
        return;
      }
      // 擴充功能：每小時抽選由 content.js 存在 chrome.storage，所有分頁共用同一次出場。
      if (ext.animalReady() && !animalBlocked() && !currentAnimal && spawnAnimal(stage, false)) {
        ext.animalShown();
      }
    }

    function tick() {
      const theme = themeNow(); // 每輪重判；開著頁面跨月／跨 19:00 也會切季。
      updateSeasonAssets(theme);
      animalTick();
      const picker = null;
      const off = !stage.isConnected || document.hidden || reducedMotion.matches || (picker && !picker.hidden);
      if (off) clearParticles();
      const density = particleSettings();
      if (!off && live.size < density.max) {
        const pets = Array.from(stage.querySelectorAll('.qpet')).filter(p => {
          const r = p.getBoundingClientRect();
          return r.width > 0 && r.bottom >= window.innerHeight - BOTTOM_ZONE &&
            r.top <= window.innerHeight;
        });
        if (pets.length) spawn(stage, theme, choose(pets));
      }
      window.setTimeout(tick, !off ? random(density.minMs, density.maxMs) : 4500);
    }

    document.addEventListener('visibilitychange', () => {
      const now = performance.now();
      if (startedWalking && wasVisible) visibleMs += Math.max(0, now - lastSample);
      lastSample = now;
      wasVisible = !document.hidden;
      pauseAnimalIfHidden(document.hidden);
      if (document.hidden) clearParticles();
    });
    if (typeof reducedMotion.addEventListener === 'function') {
      reducedMotion.addEventListener('change', e => {
        if (e.matches) { clearParticles(); removeAnimal(); }
      });
    }
    tick();
  }

  const style = document.createElement('style');
  style.textContent = ext.css;
  stage.getRootNode().appendChild(style);
  init();
};
